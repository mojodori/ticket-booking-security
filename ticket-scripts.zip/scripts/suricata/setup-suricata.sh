#!/bin/bash
# setup-suricata.sh
# queue-gate (172.16.60.146) 에서 실행
# Ubuntu 기본 저장소에 suricata 패키지가 없어 PPA 추가가 필요하다.

set -e

sudo add-apt-repository -y universe
sudo add-apt-repository -y ppa:oisf/suricata-stable
sudo apt update
sudo apt install -y suricata

# HOME_NET을 실제 네트워크 대역으로 설정
sudo sed -i 's/HOME_NET:.*/HOME_NET: "[172.16.60.0\/24]"/' /etc/suricata/suricata.yaml

# 인터페이스명을 실제 값으로 교체 (기본값 eth0 → 실제 ens160)
# 실행 전 `ip a`로 실제 인터페이스명을 반드시 확인할 것
sudo sed -i 's/eth0/ens160/g' /etc/suricata/suricata.yaml

# 용량 단위 표기 오류 수정 (100 KiB 형식은 파서가 인식하지 못함 → 100kb)
sudo sed -i 's/ KiB/kb/g; s/ MiB/mb/g; s/ GiB/gb/g' /etc/suricata/suricata.yaml

# 탐지 룰 배치 (suricata.rules를 이 스크립트와 같은 디렉터리에서 복사)
sudo mkdir -p /var/lib/suricata/rules
sudo cp ./suricata.rules /var/lib/suricata/rules/suricata.rules
sudo chown suricata:suricata /var/lib/suricata/rules/suricata.rules

# 설정 검증
sudo suricata -T -c /etc/suricata/suricata.yaml

sudo systemctl enable --now suricata
sudo systemctl status suricata --no-pager
