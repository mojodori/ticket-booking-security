// attack-sim.js
// Suricata 실전 탐지 검증용 — 예약 API에 대한 반복 요청 시뮬레이션
// 대상: queue-gate (172.16.60.146)
//
// 실행: k6 run attack-sim.js
// 확인: queue-gate에서 sudo tail -f /var/log/suricata/fast.log
//       "Excessive booking API calls detected" 알림 발생 여부 확인 (sid:1000001)

import http from 'k6/http';

export const options = {
  vus: 10,
  duration: '15s',
};

export default function () {
  http.post('http://172.16.60.146/api/book-seat', JSON.stringify({
    gameId: 1, seatId: 'A5', buyerName: 'attacker',
  }), { headers: { 'Content-Type': 'application/json' } });
}
