// traffic-spike.js
// 시나리오 2 — 트래픽 폭증 시 대기열(Rate Limiting) 효과 비교
// 대상: queue-gate (172.16.60.146)
//
// 실행 순서:
//   1) queue-gate에서 limit_req 비활성화 후 1차 실행
//        k6 run --out json=no-queue-result.json traffic-spike.js
//   2) limit_req 복원 후 2차 실행
//        k6 run --out json=with-queue-result.json traffic-spike.js
//   3) 두 결과의 checks_failed, http_req_duration max 비교

import http from 'k6/http';
import { check } from 'k6';

export const options = {
  stages: [
    { duration: '10s', target: 50 },   // 예열
    { duration: '5s',  target: 300 },  // 급증
    { duration: '20s', target: 300 },  // 유지
    { duration: '10s', target: 0 },    // 정리
  ],
};

export default function () {
  const res = http.get('http://172.16.60.146/api/health');
  check(res, {
    '정상 또는 제한 응답': (r) => [200, 429, 503].includes(r.status),
  });
}
