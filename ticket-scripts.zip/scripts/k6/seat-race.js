// seat-race.js
// 시나리오 3 — 좌석 동시성 검증
// 목적: 동일 좌석에 100건의 요청을 정확히 동시에 보내, 성공 응답이 1건만 발생하는지 확인
//
// 실행:
//   k6 run seat-race.js                                       (was-01 내부, localhost)
//   k6 run --env TARGET=http://172.16.60.145:3000 seat-race.js (외부 네트워크 경유)
//
// 판정: 실행 후 아래 쿼리 결과가 1이어야 정상
//   SELECT seat_id, COUNT(*) FROM bookings WHERE seat_id='A7' GROUP BY seat_id;

import http from 'k6/http';
import { check } from 'k6';

const TARGET = __ENV.TARGET || 'http://localhost:3000';

export const options = {
  scenarios: {
    same_seat_attack: {
      executor: 'shared-iterations',
      vus: 100,
      iterations: 100,
      maxDuration: '10s',
    },
  },
};

export default function () {
  const payload = JSON.stringify({ gameId: 1, seatId: 'A7', buyerName: `user-${__VU}` });
  const res = http.post(`${TARGET}/api/book-seat`, payload, {
    headers: { 'Content-Type': 'application/json' },
  });
  check(res, { '200 또는 409 응답': (r) => [200, 409].includes(r.status) });
}
