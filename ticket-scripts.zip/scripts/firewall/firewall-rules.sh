#!/bin/bash
# firewall-rules.sh
# 서버별 ufw 최종 규칙. 각 서버에서 해당 블록만 발췌해 실행한다.
# 공통 원칙: default deny incoming + 출발지 화이트리스트

# ── bastion (172.16.60.142) ──────────────────────────────
setup_bastion() {
  sudo ufw default deny incoming
  sudo ufw allow from "$ADMIN_IP" to any port 22 proto tcp
  sudo ufw enable
}

# ── db-01 (172.16.60.143) ────────────────────────────────
setup_db01() {
  sudo ufw default deny incoming
  sudo ufw allow from 172.16.60.145 to any port 3306 proto tcp   # was-01
  sudo ufw allow from 172.16.60.151 to any port 3306 proto tcp   # was-02
  sudo ufw allow from 172.16.60.148 to any port 3306 proto tcp   # db-01-replica (복제)
  sudo ufw allow from 172.16.60.142 to any port 22 proto tcp     # bastion
  sudo ufw enable
}

# ── db-01-replica (172.16.60.148) ────────────────────────
setup_db_replica() {
  sudo ufw default deny incoming
  sudo ufw allow from 172.16.60.145 to any port 3306 proto tcp
  sudo ufw allow from 172.16.60.151 to any port 3306 proto tcp
  sudo ufw allow from 172.16.60.142 to any port 22 proto tcp
  sudo ufw enable
}

# ── redis (172.16.60.144) ────────────────────────────────
setup_redis() {
  sudo ufw default deny incoming
  sudo ufw allow from 172.16.60.145 to any port 6379 proto tcp
  sudo ufw allow from 172.16.60.151 to any port 6379 proto tcp
  sudo ufw allow from 172.16.60.142 to any port 22 proto tcp
  sudo ufw enable
}

# ── was-01 / was-02 (172.16.60.145 / .151) ───────────────
setup_was() {
  sudo ufw default deny incoming
  sudo ufw allow from 172.16.60.147 to any port 3000 proto tcp   # web-lb에서만
  sudo ufw allow from 172.16.60.142 to any port 22 proto tcp
  sudo ufw enable
}

# ── queue-gate (172.16.60.146) ───────────────────────────
setup_queue_gate() {
  sudo ufw default deny incoming
  sudo ufw allow 80/tcp
  sudo ufw allow 443/tcp
  sudo ufw allow from 172.16.60.142 to any port 22 proto tcp
  sudo ufw enable
}

# ── web-lb (172.16.60.147) ───────────────────────────────
setup_web_lb() {
  sudo ufw default deny incoming
  sudo ufw allow from 172.16.60.146 to any port 80 proto tcp     # queue-gate에서만
  sudo ufw allow from 172.16.60.146 to any port 443 proto tcp
  sudo ufw allow from 172.16.60.142 to any port 22 proto tcp
  sudo ufw enable
}

# 사용 예:
#   ADMIN_IP=172.16.60.1
#   source firewall-rules.sh
#   setup_bastion   # 해당 서버에서 필요한 함수만 호출
