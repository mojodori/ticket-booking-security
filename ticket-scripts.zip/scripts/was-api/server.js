// server.js
// 좌석 예약 API — Redis SETNX 원자연산으로 동시성 제어
// 대상: was-01(172.16.60.145), was-02(172.16.60.151)

require('dotenv').config();
const express = require('express');
const mysql = require('mysql2/promise');
const redis = require('redis');

const app = express();
app.use(express.json());

const db = mysql.createPool({
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME,
});

const redisClient = redis.createClient({
  socket: { host: process.env.REDIS_HOST, port: 6379 },
  password: process.env.REDIS_PASSWORD,
});
redisClient.connect();

// 서버 식별용 — 로드밸런싱 확인 시 was-01 / was-02 구분에 사용
const SERVER_NAME = process.env.SERVER_NAME || 'was-01';

// 헬스체크 (정적 페이지 루트)
app.get('/', (req, res) => {
  res.json({ message: `${SERVER_NAME} 예약 API 정상 동작`, time: new Date().toISOString() });
});

// 헬스체크 (API 경로, 로드밸런싱/부하테스트 확인용)
app.get('/api/health', (req, res) => {
  res.json({ message: `${SERVER_NAME} 응답`, time: new Date().toISOString() });
});

// 좌석 예약 API
app.post('/api/book-seat', async (req, res) => {
  const { gameId, seatId, buyerName } = req.body;

  if (!gameId || !seatId || !buyerName) {
    return res.status(400).json({ message: 'gameId, seatId, buyerName은 필수예요' });
  }

  const lockKey = `seat:${gameId}:${seatId}`;

  try {
    // NX: 키가 없을 때만 설정되는 원자적 연산
    // 동시에 100건이 도착해도 정확히 1건만 성공한다
    const acquired = await redisClient.set(lockKey, buyerName, { NX: true });

    if (!acquired) {
      return res.status(409).json({ message: '이미 선택된 좌석입니다' });
    }

    // Redis 선점 성공 후 DB 기록. UNIQUE(game_id, seat_id) 제약이 2차 방어선
    await db.query(
      'INSERT INTO bookings (game_id, seat_id, buyer_name) VALUES (?, ?, ?)',
      [gameId, seatId, buyerName]
    );

    res.status(200).json({ message: '예약 성공', server: SERVER_NAME, gameId, seatId, buyerName });
  } catch (err) {
    // DB 삽입 실패 시 Redis 락 해제 (롤백)
    await redisClient.del(lockKey);
    console.error(err);
    res.status(500).json({ message: '예약 처리 중 오류가 발생했어요' });
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`${SERVER_NAME} 예약 API 서버 실행 중 :${PORT}`));
