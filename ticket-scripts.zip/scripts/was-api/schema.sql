-- schema.sql
-- db-01 (172.16.60.143) 에서 실행

CREATE DATABASE IF NOT EXISTS ticket;
USE ticket;

CREATE TABLE IF NOT EXISTS bookings (
  id INT AUTO_INCREMENT PRIMARY KEY,
  game_id INT NOT NULL,
  seat_id VARCHAR(10) NOT NULL,
  buyer_name VARCHAR(100),
  created_at DATETIME DEFAULT NOW(),
  UNIQUE KEY unique_seat (game_id, seat_id)
);

-- 계정 (최소권한 원칙)
-- was_writer: WAS의 쓰기 작업 전용, 172.16.60.0/24 대역에서만 접속 허용
CREATE USER IF NOT EXISTS 'was_writer'@'172.16.60.%' IDENTIFIED BY '__CHANGE_ME__';
GRANT SELECT, INSERT, UPDATE ON ticket.* TO 'was_writer'@'172.16.60.%';

-- replicator: db-01-replica(172.16.60.148) 전용 복제 계정
CREATE USER IF NOT EXISTS 'replicator'@'172.16.60.148' IDENTIFIED BY '__CHANGE_ME__';
GRANT REPLICATION SLAVE ON *.* TO 'replicator'@'172.16.60.148';

FLUSH PRIVILEGES;
