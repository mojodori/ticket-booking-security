# 스크립트 모음 — 티켓 예매 서비스 인프라

이 폴더는 2026-07-06 구축 세션에서 실제로 사용한 코드와 설정 파일을 정리한 것이다.
IP는 실제 구축 환경(172.16.60.0/24) 기준이며, 비밀번호 등 민감값은 플레이스홀더로 남겨두었다.

## 폴더 구조

```
scripts/
├── was-api/            예약 API 서버 (was-01, was-02에 배포)
│   ├── server.js
│   ├── package.json
│   ├── .env.example
│   └── schema.sql
├── k6/                  부하테스트 / 검증 스크립트
│   ├── seat-race.js       시나리오 3 — 좌석 동시성 검증
│   ├── traffic-spike.js   시나리오 2 — 대기열 효과 비교
│   └── attack-sim.js      Suricata 실전 탐지 검증용
├── nginx/               Nginx 설정
│   ├── queue-gate-queue.conf
│   └── web-lb-upstream.conf
├── suricata/            IDS 설정
│   ├── suricata.rules
│   └── setup-suricata.sh
└── firewall/            서버별 ufw 규칙
    └── firewall-rules.sh
```

## 배포 순서 (요약)

1. `firewall/firewall-rules.sh`의 해당 함수를 각 서버에서 실행해 방화벽부터 적용한다.
2. db-01에 `was-api/schema.sql`을 실행해 DB와 계정을 생성한다.
3. was-01, was-02에 `was-api/` 폴더를 배포하고 `.env.example`을 `.env`로 복사해 값을 채운 뒤 `npm install && npm start`.
4. queue-gate에 `nginx/queue-gate-queue.conf`, web-lb에 `nginx/web-lb-upstream.conf`를 적용한다.
   적용 전 반드시 `sudo rm /etc/nginx/sites-enabled/default`로 기본 설정을 제거해야 한다.
5. queue-gate에서 `suricata/setup-suricata.sh`를 실행해 IDS를 구성한다.
6. `k6/` 스크립트로 검증을 수행한다 — `seat-race.js`(동시성) 먼저, 이후 `traffic-spike.js`(대기열 비교),
   `attack-sim.js`(탐지 검증) 순서를 권장한다.

## 참고

- was_writer, replicator, Redis 등 모든 비밀번호는 `openssl rand -base64 24`로 생성해 사용하고,
  `.env` 파일은 반드시 `.gitignore`에 포함해 저장소에 커밋되지 않도록 한다.
- 각 스크립트의 상세 배경과 트러블슈팅 내역은 별도 `트러블슈팅-종합.pdf` 문서를 참고한다.
